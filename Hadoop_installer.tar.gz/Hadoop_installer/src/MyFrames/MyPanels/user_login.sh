su - hadoop -c "whoami"
