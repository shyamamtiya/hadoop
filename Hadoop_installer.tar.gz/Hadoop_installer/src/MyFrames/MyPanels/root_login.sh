su - root -c "whoami"
